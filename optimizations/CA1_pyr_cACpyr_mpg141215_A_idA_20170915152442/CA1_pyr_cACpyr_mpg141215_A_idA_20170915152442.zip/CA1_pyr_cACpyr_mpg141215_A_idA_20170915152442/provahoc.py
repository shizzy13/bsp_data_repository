import os
import sys
import pickle
import bluepyopt
map_function = None
BLUEPYOPT_SEED =7
import model
evaluator = model.evaluator.create('CA1_PC_cAC_sig', cvode_active=True, dt=0.025)
opt = bluepyopt.optimisations.DEAPOptimisation(evaluator=evaluator,map_function=map_function,seed=BLUEPYOPT_SEED)
cp_filename='./checkpoints/run.881606.r000u17l01/seed5.pkl'
import os
cp = pickle.load(open(cp_filename, "r"))
hof = cp['halloffame']
parameter_values = opt.evaluator.param_dict(hof[0])
fitness_protocols = opt.evaluator.fitness_protocols

replace_axon_hoc = """
    proc replace_axon(){local nSec, L_chunk, dist, i1, i2, count, L_target, chunkSize, L_real localobj diams, lens

     L_target = 60  // length of stub axon
     nseg0 = 5  // number of segments for each of the two axon sections

     nseg_total = nseg0 * 2
     chunkSize = L_target/nseg_total

     nSec = 0
     forsec axonal{nSec = nSec + 1}

     // Try to grab info from original axon
     if(nSec < 1){ //At least two axon sections have to be present!

         execerror("Less than two axon sections are present! Add an axon to the morphology and try again!")

     } else {

         diams = new Vector()
         lens = new Vector()

         access axon[0]
         i1 = v(0.0001) // used when serializing sections prior to sim start

         access axon[1]
         i2 = v(0.0001) // used when serializing sections prior to sim start

         count = 0
         forsec axonal{ // loop through all axon sections

	     nseg = 1 + int(L/chunkSize/2.)*2  //nseg to get diameter

         for (x) {
             if (x > 0 && x < 1) {
                 count = count + 1
                 diams.resize(count)
                 diams.x[count-1] = diam(x)
                 lens.resize(count)
                 lens.x[count-1] = L/nseg
                 if( count == nseg_total ){
                     break
                 }
             }
         }
         if( count == nseg_total ){
             break
	 }
     }

         // get rid of the old axon
         forsec axonal{delete_section()}
         execute1("create axon[2]", CellRef)

         L_real = 0
         count = 0

         // new axon dependant on old diameters
         for i=0,1{
             access axon[i]
             L =  L_target/2
             nseg = nseg_total/2

             for (x) {
                 if (x > 0 && x < 1) {
                     diam(x) = diams.x[count]
                     L_real = L_real+lens.x[count]
                     count = count + 1
                 }
             }

             all.append()
             axonal.append()

             if (i == 0) {
                 v(0.0001) = i1
             } else {
                 v(0.0001) = i2
             }
         }

         nSecAxonal = 2
         soma[0] connect axon[0](0), 1
         axon[0] connect axon[1](0), 1

         print "Target stub axon length:", L_target, "um, equivalent length: ", L_real "um"
     }

 }

    """
#opt.evaluator.cell_model.morphology.replace_axon.func_globals['NrnFileMorphology'].default_replace_axon_hoc=replace_axon_hoc
opt.evaluator.cell_model.morphology.replace_axon_hoc=replace_axon_hoc
#hoccode =  opt.evaluator.cell_model.create_hoc(param_values=parameter_values)
#cp_dir = os.path.dirname(cp_filename)

#with open(cp_dir + "/cellBPOPTG.hoc", "w") as f:
#    f.write(hoccode)

responses = {}
traces=[]
for i in range(len(fitness_protocols)-3,len(fitness_protocols)):
    protocol = fitness_protocols[sorted(fitness_protocols.keys())[i]]
    traces.append(sorted(fitness_protocols.keys())[i][sorted(fitness_protocols.keys())[i].find('_')+1:len(sorted(fitness_protocols.keys())[i])]+' nA')
    response = protocol.run(
      cell_model=opt.evaluator.cell_model,
      param_values=parameter_values,
      sim=opt.evaluator.sim)
    responses.update(response)
keysD={}
for i in range(len(responses)):
  keysD[sorted(responses.keys())[i]]=traces[i]
responsesN={}
for key, value in responses.items():
    responsesN[keysD[key]] = value
import matplotlib.pyplot as plt
traces = tuple(traces)
responses_fig = plt.figure(figsize=(10, 10), facecolor='white')
#plt.axes(frameon=False)
#plt.xticks([])
#plt.yticks([])
#plt.ylabel('Voltage (mV)')
model.analysis.plot_multiple_responses2([responsesN], traces, fig=responses_fig)
responses_fig.savefig('figures/neuron_responses.png',bbox_inches='tight')

